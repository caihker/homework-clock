/* BUILD is injected by build-offline.mjs. No external imports are needed. */
const PREFIX = `homework-clock:${self.registration.scope}:`;
const CACHE = PREFIX + BUILD.version;
const scope = new URL(self.registration.scope);
const assets = new Map(BUILD.assets.map(asset => [new URL(asset.url, scope).href, asset]));
const indexURL = new URL('./index.html', scope).href;
let repairPromise;

async function broadcast(message) {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of clients) client.postMessage({ source: 'homework-clock-offline', ...message });
}

async function digest(response) {
  const hash = await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer());
  return Array.from(new Uint8Array(hash), byte => byte.toString(16).padStart(2, '0')).join('');
}

async function fillCache(cache, onlyMissing = false) {
  let complete = 0;
  // Fetch sequentially: large animation/font files should not compete for iPad memory.
  for (const [url, asset] of assets) {
    if (!onlyMissing || !await cache.match(url)) {
      const response = await fetch(new Request(url, { cache: 'reload', credentials: 'same-origin', redirect: 'error' }));
      if (!response.ok || response.type === 'opaque' || await digest(response) !== asset.sha256) {
        throw new Error('Incomplete or changed offline resource: ' + asset.url);
      }
      await cache.put(url, response);
    }
    complete++;
    await broadcast({ type: 'PROGRESS', version: BUILD.version, complete, total: assets.size });
  }
}

async function cacheStatus() {
  const cache = await caches.open(CACHE);
  for (const url of assets.keys()) {
    if (!await cache.match(url)) return { ready: false, version: BUILD.version, total: assets.size };
  }
  return { ready: true, version: BUILD.version, total: assets.size };
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    try {
      await fillCache(await caches.open(CACHE));
      await broadcast({ type: 'PREPARED', version: BUILD.version });
      // Updates wait until old windows have closed. Never interrupt an active timer.
    } catch (error) {
      await caches.delete(CACHE);
      await broadcast({ type: 'FAILED', version: BUILD.version });
      throw error;
    }
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    // Storage may have been evicted while an update was waiting for old windows.
    // Keep the previous complete snapshot if this snapshot cannot be repaired.
    if (!(await cacheStatus()).ready) {
      try {
        await fillCache(await caches.open(CACHE), true);
      } catch (error) {
        await broadcast({ type: 'FAILED', version: BUILD.version });
        throw error;
      }
    }
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith(PREFIX) && name !== CACHE).map(name => caches.delete(name)));
    // No clients.claim(): an already open page must not mix old code and new assets.
    await broadcast({ type: 'ACTIVATED', version: BUILD.version });
  })());
});

async function partialResponse(request, response) {
  const range = request.headers.get('range');
  if (!range) return response;
  // iPad Safari commonly asks for the first two bytes before playing local audio.
  const match = /^bytes=(\d*)-(\d*)$/i.exec(range.trim());
  if (!match || (!match[1] && !match[2])) return response;
  const buffer = await response.arrayBuffer();
  const size = buffer.byteLength;
  const start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
  const end = match[1] && match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start >= size || start > end) {
    return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
  }
  const headers = new Headers(response.headers);
  headers.set('Content-Range', `bytes ${start}-${end}/${size}`);
  headers.set('Content-Length', String(end - start + 1));
  headers.set('Accept-Ranges', 'bytes');
  headers.delete('Content-Encoding');
  return new Response(buffer.slice(start, end + 1), { status: 206, statusText: 'Partial Content', headers });
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== scope.origin) return;
  url.search = '';
  url.hash = '';
  if (url.href === scope.href && request.mode === 'navigate') url.href = indexURL;
  if (!assets.has(url.href)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(url.href);
    if (cached) return partialResponse(request, cached);
    // An evicted resource can be repaired only with the exact installed build.
    // Do not silently serve a newer script into an older running application.
    try {
      const response = await fetch(new Request(url.href, { cache: 'reload', credentials: 'same-origin', redirect: 'error' }));
      if (response.ok && await digest(response) === assets.get(url.href).sha256) {
        await cache.put(url.href, response.clone());
        return partialResponse(request, response);
      }
    } catch {}
    if (request.mode === 'navigate') {
      return new Response('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>作业时钟</title><body style="font:20px system-ui;padding:32px;background:#fffdf5;color:#293a35"><h1>需要重新准备离线资源</h1><p>请联网后重新打开作业时钟。你保存的计划不受这次加载失败影响。</p></body></html>', { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    return Response.error();
  })());
});

self.addEventListener('message', event => {
  const respond = data => event.ports[0]?.postMessage(data);
  if (event.data?.type === 'OFFLINE_STATUS') {
    event.waitUntil(cacheStatus().then(respond).catch(() => respond({ ready: false, version: BUILD.version })));
  }
  if (event.data?.type === 'REPAIR_OFFLINE') {
    if (!repairPromise) {
      repairPromise = fillCachePromise();
    }
    event.waitUntil(repairPromise.then(respond));
  }
});

async function fillCachePromise() {
  try {
    await fillCache(await caches.open(CACHE), true);
    return await cacheStatus();
  } catch {
    return { ready: false, version: BUILD.version };
  } finally {
    repairPromise = undefined;
  }
}
