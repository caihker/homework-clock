import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash, webcrypto } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const template = await readFile(new URL('../scripts/service-worker.template.js', import.meta.url), 'utf8');
const scope = 'https://clock.example.test/homework/';
const prefix = `homework-clock:${scope}:`;
const hash = content => createHash('sha256').update(content).digest('hex');
const resources = {
  './index.html': '<!doctype html><html>作业时钟</html>',
  './app.mjs': 'export const version = "old";',
  './assets/voice.mp3': Uint8Array.from([10, 20, 30, 40, 50, 60]),
  './assets/never-used.woff2': Uint8Array.from([1, 5, 9]),
};

function storage() {
  const stores = new Map();
  return {
    stores,
    async open(name) {
      if (!stores.has(name)) stores.set(name, new Map());
      const entries = stores.get(name);
      return {
        async match(key) { return entries.get(String(key))?.clone(); },
        async put(key, value) { entries.set(String(key), value.clone()); },
        async delete(key) { return entries.delete(String(key)); },
      };
    },
    async keys() { return [...stores.keys()]; },
    async delete(name) { return stores.delete(name); },
  };
}

function worker({ version = 'old', files = resources, cacheStorage = storage(), overrides = {}, network = true } = {}) {
  const handlers = new Map();
  const messages = [];
  const requests = [];
  const build = {
    version,
    assets: Object.entries(files).map(([url, content]) => ({ url, sha256: hash(content) })),
  };
  const context = vm.createContext({
    BUILD: build,
    URL, Request, Response, Headers,
    crypto: webcrypto,
    caches: cacheStorage,
    fetch: async request => {
      requests.push(request);
      if (!network) throw new Error('offline');
      const local = './' + new URL(request.url).pathname.slice(new URL(scope).pathname.length);
      const content = Object.hasOwn(overrides, local) ? overrides[local] : files[local];
      if (content === undefined) return new Response('missing', { status: 404 });
      return new Response(content, { headers: { 'Content-Type': local.endsWith('.mp3') ? 'audio/mpeg' : 'text/plain' } });
    },
    self: {
      registration: { scope },
      clients: { matchAll: async () => [{ postMessage: message => messages.push(message) }] },
      addEventListener: (name, handler) => handlers.set(name, handler),
    },
  });
  vm.runInContext(template, context);
  return {
    cacheStorage, messages, requests,
    async dispatch(name, properties = {}) {
      let waiting;
      let response;
      handlers.get(name)?.({
        ...properties,
        waitUntil: promise => { waiting = promise; },
        respondWith: promise => { response = promise; },
      });
      await waiting;
      return response;
    },
    async status(type = 'OFFLINE_STATUS') {
      let result;
      await this.dispatch('message', { data: { type }, ports: [{ postMessage: value => { result = value; } }] });
      return result;
    },
    request(path, { range, navigate = false } = {}) {
      return this.dispatch('fetch', { request: { url: new URL(path, scope).href, method: 'GET', mode: navigate ? 'navigate' : 'cors', headers: new Headers(range ? { range } : {}) } });
    },
  };
}

test('first install includes unused resources and cache cleanup is limited to this app scope', async () => {
  const instance = worker();
  const other = 'another-app:cache';
  const anotherScope = 'homework-clock:https://clock.example.test/other/:old';
  await instance.cacheStorage.open(prefix + 'previous');
  await instance.cacheStorage.open(other);
  await instance.cacheStorage.open(anotherScope);
  await instance.dispatch('install');
  assert.equal((await instance.status()).ready, true);
  assert.equal(instance.requests.length, Object.keys(resources).length);
  assert.ok(instance.requests.every(request => request.redirect === 'error' && request.cache === 'reload'));
  assert.ok(instance.requests.some(request => request.url.endsWith('never-used.woff2')));
  // Installing a new snapshot does not delete the one currently in use.
  assert.ok((await instance.cacheStorage.keys()).includes(prefix + 'previous'));
  await instance.dispatch('activate');
  assert.deepEqual((await instance.cacheStorage.keys()).sort(), [other, anotherScope, prefix + 'old'].sort());
});

test('failed or mismatched downloads discard only the incomplete new snapshot', async () => {
  const cacheStorage = storage();
  const old = worker({ cacheStorage });
  await old.dispatch('install');
  const next = worker({ version: 'next', cacheStorage, overrides: { './app.mjs': 'unexpected content from another release' } });
  await assert.rejects(next.dispatch('install'), /Incomplete or changed/);
  assert.deepEqual(await cacheStorage.keys(), [prefix + 'old']);
  assert.equal((await old.status()).ready, true);
  assert.ok(next.messages.some(message => message.type === 'FAILED'));
});

test('an installed update leaves the active build intact until activation', async () => {
  const cacheStorage = storage();
  const old = worker({ cacheStorage });
  await old.dispatch('install');
  const files = { ...resources, './app.mjs': 'export const version = "next";' };
  const next = worker({ version: 'next', cacheStorage, files });
  await next.dispatch('install');
  assert.match(await (await old.request('./app.mjs?v=anything')).text(), /"old"/);
  assert.equal((await old.status()).ready, true);
  assert.equal((await next.status()).ready, true);
  await next.dispatch('activate');
  assert.match(await (await next.request('./app.mjs?v=next')).text(), /"next"/);
  assert.deepEqual(await cacheStorage.keys(), [prefix + 'next']);
});

test('cached navigation and Safari audio ranges work without network', async () => {
  const cacheStorage = storage();
  await worker({ cacheStorage }).dispatch('install');
  const offline = worker({ cacheStorage, network: false });
  assert.match(await (await offline.request('./?from=homescreen', { navigate: true })).text(), /作业时钟/);
  const head = await offline.request('./assets/voice.mp3', { range: 'bytes=0-1' });
  assert.equal(head.status, 206);
  assert.equal(head.headers.get('content-range'), 'bytes 0-1/6');
  assert.deepEqual([...new Uint8Array(await head.arrayBuffer())], [10, 20]);
  const suffix = await offline.request('./assets/voice.mp3', { range: 'bytes=-2' });
  assert.deepEqual([...new Uint8Array(await suffix.arrayBuffer())], [50, 60]);
  assert.equal((await offline.request('./assets/voice.mp3', { range: 'bytes=9-' })).status, 416);
  assert.equal(await offline.request('https://other.example.test/resource'), undefined);
  assert.equal(offline.requests.length, 0);
});

test('activation retains the previous complete snapshot when waiting cache was evicted', async () => {
  const cacheStorage = storage();
  const old = worker({ cacheStorage });
  await old.dispatch('install');
  await worker({ version: 'next', cacheStorage }).dispatch('install');
  const nextCache = await cacheStorage.open(prefix + 'next');
  await nextCache.delete(new URL('./app.mjs', scope).href);
  const offlineNext = worker({ version: 'next', cacheStorage, network: false });
  await assert.rejects(offlineNext.dispatch('activate'), /offline/);
  assert.ok((await cacheStorage.keys()).includes(prefix + 'old'));
  assert.equal((await old.status()).ready, true);
});

test('cache eviction is reported and repair refuses files from a newer build', async () => {
  const cacheStorage = storage();
  const initial = worker({ cacheStorage });
  await initial.dispatch('install');
  const cache = await cacheStorage.open(prefix + 'old');
  await cache.delete(new URL('./app.mjs', scope).href);
  const wrong = worker({ cacheStorage, overrides: { './app.mjs': 'new release' } });
  assert.equal((await wrong.status()).ready, false);
  assert.equal((await wrong.status('REPAIR_OFFLINE')).ready, false);
  assert.equal((await wrong.request('./app.mjs')).type, 'error');
  assert.equal(await cache.match(new URL('./app.mjs', scope).href), undefined);
  const matching = worker({ cacheStorage });
  assert.equal((await matching.status('REPAIR_OFFLINE')).ready, true);
  assert.match(await (await matching.request('./app.mjs')).text(), /"old"/);
});
