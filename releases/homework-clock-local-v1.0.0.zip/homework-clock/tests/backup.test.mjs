import test from 'node:test';
import assert from 'node:assert/strict';
import { createBackup, parseBackup, MAX_BACKUP_BYTES } from '../dist/backup.mjs';
import { createSession, pauseSession } from '../dist/session-timer.mjs';

const minute = 60_000;
const at = (hour, minutes = 0) => new Date(2026, 10, 1, hour, minutes).getTime();
const task = { id: 'chinese', date: '2026-11-01', title: '语文预习', start: '10:00', end: '12:00', type: 'study', subject: '语文', completed: true };
const fixture = () => ({
  version: 1,
  tasks: [{ ...task }],
  selectedDate: task.date,
  settings: { sound: true, pet: true, code: '小皮开工了', message: '先做一道！', voice: 'data:audio/mp4;codecs=mp4a.40.2;base64,YXVkaW8=' },
  history: [{ id: 'earlier', taskId: 'deleted-task', date: task.date, type: 'study', ms: 15 * minute }],
  session: null,
  clock: { mode: 'real' },
  notified: ['chinese:10:00:12:00:start'],
});

test('backup round trip retains plans, completion, deleted-task history, settings and recording', () => {
  const original = fixture();
  const exported = createBackup(original, at(11));
  const envelope = JSON.parse(exported);
  assert.equal(envelope.schema, 'homework-clock-backup');
  assert.equal(envelope.version, 1);
  assert.equal(envelope.exportedAt, new Date(at(11)).toISOString());
  const restored = parseBackup(exported);
  assert.deepEqual(restored, { ...original, localUseVersion: 1 });
  restored.tasks[0].title = '新名字';
  assert.equal(original.tasks[0].title, '语文预习');
});

test('an active break is archived once at export, without changing the live timer', () => {
  const original = fixture();
  original.session = pauseSession(createSession(task, at(10, 20)), task, at(10, 40));
  const before = structuredClone(original);
  const restored = parseBackup(createBackup(original, at(10, 47)));
  assert.equal(restored.session, null);
  assert.deepEqual(restored.clock, { mode: 'real' });
  assert.equal(restored.history.length, 2);
  assert.equal(restored.history[1].ms, 22 * minute);
  assert.deepEqual(original, before);
  const secondRestore = parseBackup(createBackup(restored, at(11)));
  assert.deepEqual(secondRestore.history, restored.history);
});

test('expired timers stop at the fixed plan end and demo timers use their simulated time', () => {
  const original = fixture();
  original.session = createSession(task, at(10, 20));
  assert.equal(parseBackup(createBackup(original, at(14))).history[1].ms, 100 * minute);
  original.clock = { mode: 'demo', simulatedAt: at(10, 40), anchor: at(17) };
  const restored = parseBackup(createBackup(original, at(17, 5)));
  assert.equal(restored.history[1].ms, 25 * minute);
  assert.deepEqual(restored.clock, { mode: 'real' });
});

test('legacy v1 JSON can migrate, with a fresh real clock and no restored live timer', () => {
  const original = fixture();
  delete original.settings.sound;
  delete original.settings.voice;
  delete original.tasks[0].completed;
  delete original.history[0].type;
  const restored = parseBackup(JSON.stringify(original));
  assert.equal(restored.localUseVersion, 1);
  assert.equal(restored.settings.sound, true);
  assert.equal(restored.settings.voice, null);
  assert.equal(restored.tasks[0].completed, false);
  assert.equal(restored.session, null);
  // Legacy non-ten-minute times are not silently changed during migration.
  original.tasks[0].start = '07:35';
  assert.equal(parseBackup(JSON.stringify(original)).tasks[0].start, '07:35');
});

test('malformed, unrelated, oversized, future-version and prototype-bearing files are rejected', () => {
  for (const input of ['not JSON', 'null', '[]', '{}', '{"hello":"world"}', ' '.repeat(MAX_BACKUP_BYTES + 1)]) {
    assert.throws(() => parseBackup(input));
  }
  const envelope = JSON.parse(createBackup(fixture(), at(11)));
  envelope.version = 2;
  assert.throws(() => parseBackup(JSON.stringify(envelope)));
  const proto = JSON.stringify(fixture()).replace('"version":1', '"version":1,"__proto__":{"polluted":true}');
  assert.throws(() => parseBackup(proto));
  assert.equal({}.polluted, undefined);
  const largeUnicode = fixture();
  largeUnicode.settings.code = '皮'.repeat(41);
  assert.throws(() => createBackup(largeUnicode));
});

test('task dates, ids, types, times, overlap and settings types must be valid before restore', () => {
  const changes = [
    state => { state.selectedDate = '2026-02-30'; },
    state => { state.tasks[0].date = '2026-13-01'; },
    state => { state.tasks[0].type = 'other'; },
    state => { state.tasks[0].start = '25:00'; },
    state => { state.tasks[0].end = '09:00'; },
    state => { state.tasks.push({ ...state.tasks[0] }); },
    state => { state.tasks.push({ ...state.tasks[0], id: 'overlap', start: '11:00' }); },
    state => { state.settings.sound = 'true'; },
    state => { state.tasks[0].completed = 'false'; },
    state => { state.history[0].ms = -1; },
    state => { state.history[0].ms = 86400001; },
  ];
  for (const change of changes) {
    const original = fixture();
    change(original);
    assert.throws(() => parseBackup(JSON.stringify(original)));
  }
  const adjacent = fixture();
  adjacent.tasks.push({ ...task, id: 'lunch', start: '12:00', end: '12:30', type: 'life' });
  assert.equal(parseBackup(JSON.stringify(adjacent)).tasks.length, 2);
});

test('restored family audio must be a small embedded audio recording, never an external or script URL', () => {
  const unsafe = [
    'https://example.com/track.mp3',
    'javascript:alert(1)',
    'data:text/html;base64,PHNjcmlwdD4=',
    'data:audio/mp4;base64,broken===',
    'data:audio/mp4;base64,AA=A',
    `data:audio/mp4;base64,${'A'.repeat(Math.ceil(1024 * 1024 / 3) * 4 + 4)}`,
  ];
  for (const voice of unsafe) {
    const original = fixture();
    original.settings.voice = voice;
    assert.throws(() => parseBackup(JSON.stringify(original)));
  }
  for (const mime of ['webm;codecs=opus', 'ogg;codecs=opus', 'mp4', 'mpeg']) {
    const original = fixture();
    original.settings.voice = `data:audio/${mime};base64,YXVkaW8=`;
    assert.equal(parseBackup(createBackup(original)).settings.voice, original.settings.voice);
  }
});

test('malicious or disconnected timing records do not enter a restored state', () => {
  const changes = [
    state => { state.session.taskId = 'missing'; },
    state => { state.session.date = '2026-11-02'; },
    state => { state.session.startedAt = at(13); },
    state => { state.session.accumulatedMs = -1; },
    state => { state.session.paused = 'false'; },
    state => { state.session.pausedAt = at(9); },
    state => { state.session.breakEndsAt = at(13); },
    state => { state.clock = { mode: 'demo', simulatedAt: null, anchor: at(10) }; },
  ];
  for (const change of changes) {
    const original = fixture();
    original.session = createSession(task, at(10));
    change(original);
    assert.throws(() => parseBackup(JSON.stringify(original)));
  }
});
