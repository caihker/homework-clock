import test from 'node:test';
import assert from 'node:assert/strict';
import {
  toMinutes, toTime, dateKey, durationMinutes, isConflict,
  validateTask, remainingSeconds, createSampleTasks,
} from '../dist/core.mjs';

const base = { id: 'chinese', date: '2026-11-01', title: '语文预习', start: '10:00', end: '12:00', type: 'study' };

test('strict time parsing and formatting cover day boundaries', () => {
  assert.equal(toMinutes('00:00'), 0);
  assert.equal(toMinutes('10:20'), 620);
  assert.equal(toMinutes('23:59'), 1439);
  for (const invalid of ['24:00', '12:60', '9:00', '12:0', '', null, 600]) {
    assert.ok(Number.isNaN(toMinutes(invalid)), `${invalid} must be invalid`);
  }
  assert.equal(toTime(0), '00:00');
  assert.equal(toTime(620), '10:20');
  assert.equal(toTime(1439), '23:59');
  for (const invalid of [-1, 1440, NaN, 1.5, '600']) assert.equal(toTime(invalid), '');
});

test('local date keys do not accidentally use the UTC date', () => {
  assert.equal(dateKey(new Date(2026, 10, 1, 0, 5)), '2026-11-01');
  assert.equal(dateKey(new Date(2026, 0, 9, 23, 59)), '2026-01-09');
  assert.equal(dateKey(new Date('not-a-date')), '');
});

test('task validation rejects empty names, bad dates, reversed and cross-day times', () => {
  assert.equal(validateTask(base), '');
  assert.ok(validateTask({ ...base, title: '  ' }));
  assert.ok(validateTask({ ...base, date: '2026-02-30' }));
  assert.ok(validateTask({ ...base, start: '24:00' }));
  assert.ok(validateTask({ ...base, end: '10:00' }));
  assert.ok(validateTask({ ...base, start: '23:00', end: '01:00' }));
  assert.ok(validateTask({ ...base, type: 'unknown' }));
  assert.equal(durationMinutes(base), 120);
  assert.equal(durationMinutes({ ...base, end: '09:00' }), 0);
  assert.equal(durationMinutes(null), 0);
});

test('adjacent plans are valid but intersecting, contained and equal slots conflict', () => {
  assert.equal(isConflict({ ...base, id: 'later', start: '12:00', end: '12:30' }, [base]), false);
  assert.equal(isConflict({ ...base, id: 'earlier', start: '09:00', end: '10:00' }, [base]), false);
  assert.equal(isConflict({ ...base, id: 'overlap', start: '11:00', end: '12:30' }, [base]), true);
  assert.equal(isConflict({ ...base, id: 'within', start: '10:30', end: '11:00' }, [base]), true);
  assert.equal(isConflict({ ...base, id: 'covers', start: '09:00', end: '13:00' }, [base]), true);
  assert.equal(isConflict({ ...base, id: 'equal' }, [base]), true);
  assert.ok(validateTask({ ...base, id: 'overlap' }, [base]));
});

test('editing the same record and plans on different dates do not conflict', () => {
  assert.equal(isConflict(base, [base]), false);
  assert.equal(validateTask(base, [base]), '');
  assert.equal(isConflict({ ...base, id: 'tomorrow', date: '2026-11-02' }, [base]), false);
});

test('late starts retain the original finish and countdown cannot become negative', () => {
  assert.equal(remainingSeconds(base, new Date(2026, 10, 1, 10, 20)), 100 * 60);
  assert.equal(remainingSeconds(base, new Date(2026, 10, 1, 11, 0)), 60 * 60);
  assert.equal(remainingSeconds(base, new Date(2026, 10, 1, 11, 59, 59)), 1);
  assert.equal(remainingSeconds(base, new Date(2026, 10, 1, 12, 0)), 0);
  assert.equal(remainingSeconds(base, new Date(2026, 10, 1, 13, 0)), 0);
  assert.equal(remainingSeconds(base, new Date(2026, 10, 1, 9, 0)), 120 * 60);
  assert.equal(remainingSeconds(base, new Date(2026, 10, 2, 10, 0)), 0);
  assert.equal(remainingSeconds(base, new Date(), '2026-02-30'), 0);
});

test('sample plans preserve all four requested slots and independent mutable state', () => {
  const tasks = createSampleTasks('2026-11-01');
  assert.equal(tasks.length, 4);
  assert.deepEqual(tasks.map(({ start, end }) => [start, end]), [
    ['10:00', '12:00'], ['12:30', '13:30'], ['14:00', '15:00'], ['15:30', '17:50'],
  ]);
  assert.deepEqual(tasks.map(({ type }) => type), ['study', 'life', 'play', 'study']);
  assert.equal(new Set(tasks.map(({ id }) => id)).size, 4);
  for (const task of tasks) {
    assert.equal(task.date, '2026-11-01');
    assert.equal(task.completed, false);
    assert.equal(validateTask(task, tasks), '');
  }
  tasks[0].completed = true;
  assert.equal(createSampleTasks('2026-11-01')[0].completed, false);
  assert.deepEqual(createSampleTasks('bad-date'), []);
});
