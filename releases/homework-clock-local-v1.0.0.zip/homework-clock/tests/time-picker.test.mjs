import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizePickerMinutes, pickerMinutesForHour, isWithinSchedulingWindow } from '../dist/time-picker.mjs';

test('picker clamps to 08:00–21:00 without offering later minutes at 21', () => {
  assert.equal(normalizePickerMinutes('07:50'), 480);
  assert.equal(normalizePickerMinutes('21:50'), 1260);
  assert.equal(normalizePickerMinutes('18:23'), 1100);
  assert.deepEqual(pickerMinutesForHour(8), [0, 10, 20, 30, 40, 50]);
  assert.deepEqual(pickerMinutesForHour(20), [0, 10, 20, 30, 40, 50]);
  assert.deepEqual(pickerMinutesForHour(21), [0]);
  assert.deepEqual(pickerMinutesForHour(7), []);
});
test('scheduling boundaries include 08:00 and 21:00', () => {
  assert.equal(isWithinSchedulingWindow('08:00'), true);
  assert.equal(isWithinSchedulingWindow('21:00'), true);
  assert.equal(isWithinSchedulingWindow('07:50'), false);
  assert.equal(isWithinSchedulingWindow('21:10'), false);
});
